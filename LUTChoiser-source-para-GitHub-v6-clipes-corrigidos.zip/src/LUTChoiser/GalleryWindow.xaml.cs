using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using LutChoiser.Models;
using LutChoiser.Services;

namespace LutChoiser;

public partial class GalleryWindow : Window
{
    private const int PreviewsPerPage = 6;
    private static readonly TimeSpan PreviewDuration = TimeSpan.FromSeconds(5);
    private readonly string _videoPath;
    private readonly string _lutFolder;
    private readonly TimeSpan _selectedTime;
    private readonly FfmpegService _ffmpeg = new();
    private readonly ObservableCollection<LutPreview> _previews = [];
    private readonly ObservableCollection<LutPreview> _visiblePreviews = [];
    private readonly string _workspace = Path.Combine(Path.GetTempPath(), "LUT-Choiser", Guid.NewGuid().ToString("N"));
    private CancellationTokenSource? _generationCancellation;
    private bool _isGenerating;
    private bool _suppressSelectionChanges;
    private int _currentPage;

    public GalleryWindow(string videoPath, string lutFolder, TimeSpan selectedTime)
    {
        _videoPath = videoPath;
        _lutFolder = lutFolder;
        _selectedTime = selectedTime;
        InitializeComponent();
        Directory.CreateDirectory(_workspace);
        PreviewList.ItemsSource = _visiblePreviews;
        FrameInfoText.Text = $"Início dos clipes: {FormatTime(_selectedTime)}  •  5 segundos por LUT  •  {GetLutFiles().Count} LUTs encontrados";
    }

    private async void GalleryWindow_Loaded(object sender, RoutedEventArgs e) => await StartNewPreviewSetAsync();

    private async void Regenerate_Click(object sender, RoutedEventArgs e) => await StartNewPreviewSetAsync();

    private async Task StartNewPreviewSetAsync()
    {
        if (_isGenerating) return;
        var luts = GetLutFiles();
        if (luts.Count == 0)
        {
            StatusText.Text = "A pasta selecionada não possui arquivos .cube.";
            return;
        }

        _currentPage = 0;
        _previews.Clear();
        _suppressSelectionChanges = true;
        PreviewList.SelectedItems.Clear();
        _suppressSelectionChanges = false;
        SelectedLutText.Text = "Clique nas miniaturas de que você gostar. É possível selecionar mais de uma.";
        ExportButton.IsEnabled = false;
        PdfButton.IsEnabled = false;
        foreach (var lut in luts) _previews.Add(new LutPreview(lut));
        ShowCurrentPage();
        await GenerateCurrentPageAsync();
    }

    private async void PreviousPage_Click(object sender, RoutedEventArgs e)
    {
        if (_isGenerating || _currentPage == 0) return;
        try
        {
            _currentPage--;
            ShowCurrentPage();
            await GenerateCurrentPageAsync();
        }
        catch (Exception ex)
        {
            ShowPageNavigationError(ex);
        }
    }

    private async void NextPage_Click(object sender, RoutedEventArgs e)
    {
        if (_isGenerating || _currentPage >= GetPageCount() - 1) return;
        try
        {
            _currentPage++;
            ShowCurrentPage();
            await GenerateCurrentPageAsync();
        }
        catch (Exception ex)
        {
            ShowPageNavigationError(ex);
        }
    }

    private async Task GenerateCurrentPageAsync()
    {
        if (_isGenerating) return;
        var previewsToGenerate = _visiblePreviews.Where(preview => !preview.IsReady).ToList();
        if (previewsToGenerate.Count == 0)
        {
            StatusText.Text = "Estes seis clipes já estão prontos.";
            UpdateActionAvailability();
            return;
        }

        _isGenerating = true;
        _generationCancellation = new CancellationTokenSource();
        var token = _generationCancellation.Token;
        var renderFolder = Path.Combine(_workspace, Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(renderFolder);
        var completed = 0;
        var errors = 0;
        using var limiter = new SemaphoreSlim(2);
        StatusText.Text = $"Gerando 0 de {previewsToGenerate.Count} clipes de 5 segundos…";
        UpdateActionAvailability();

        try
        {
            var tasks = previewsToGenerate.Select(async (preview, index) =>
            {
                var slotAcquired = false;
                try
                {
                    await limiter.WaitAsync(token);
                    slotAcquired = true;
                    await Dispatcher.InvokeAsync(() => preview.StateLabel = "Gerando…");
                    var videoOutput = Path.Combine(renderFolder, $"{index:D4}.mp4");
                    var thumbnailOutput = Path.Combine(renderFolder, $"{index:D4}.jpg");
                    await _ffmpeg.CreateLutPreviewVideoAsync(_videoPath, _selectedTime, PreviewDuration, preview.Path, videoOutput, token);
                    await _ffmpeg.CreateLutPreviewAsync(_videoPath, _selectedTime, preview.Path, thumbnailOutput, token);
                    await Dispatcher.InvokeAsync(() =>
                    {
                        preview.ThumbnailPath = thumbnailOutput;
                        preview.ThumbnailUri = new Uri(thumbnailOutput, UriKind.Absolute);
                        preview.PreviewVideoUri = new Uri(videoOutput, UriKind.Absolute);
                        preview.StateLabel = "Pronta";
                    });
                }
                catch (OperationCanceledException)
                {
                    await Dispatcher.InvokeAsync(() => preview.StateLabel = "Cancelada");
                }
                catch (Exception ex)
                {
                    Interlocked.Increment(ref errors);
                    await Dispatcher.InvokeAsync(() =>
                    {
                        preview.StateLabel = "Não foi possível gerar";
                        preview.Detail = ex.Message;
                    });
                }
                finally
                {
                    if (slotAcquired) limiter.Release();
                    var done = Interlocked.Increment(ref completed);
                    await Dispatcher.InvokeAsync(() => StatusText.Text = $"Gerando {done} de {previewsToGenerate.Count} clipes de 5 segundos…");
                }
            });

            await Task.WhenAll(tasks);
            StatusText.Text = token.IsCancellationRequested
                ? "Geração cancelada. Os clipes concluídos continuam disponíveis."
                : errors == 0
                    ? $"{previewsToGenerate.Count} clipes prontos. Clique em um ou mais para selecioná-los."
                    : $"Concluído: {previewsToGenerate.Count - errors} clipes prontos e {errors} com falha.";
        }
        finally
        {
            _generationCancellation?.Dispose();
            _generationCancellation = null;
            _isGenerating = false;
            UpdateActionAvailability();
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        _generationCancellation?.Cancel();
        CancelButton.IsEnabled = false;
        StatusText.Text = "Cancelando as prévias em andamento…";
    }

    private void Back_Click(object sender, RoutedEventArgs e) => Close();

    private void Previews_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSelectionChanges) return;
        foreach (var preview in e.AddedItems.OfType<LutPreview>()) preview.IsSelected = true;
        foreach (var preview in e.RemovedItems.OfType<LutPreview>()) preview.IsSelected = false;

        var selected = GetSelectedReadyPreviews();
        var selectedCount = _previews.Count(preview => preview.IsSelected);
        if (selectedCount == 0)
        {
            ExportButton.IsEnabled = false;
            PdfButton.IsEnabled = false;
            SelectedLutText.Text = "Clique nas miniaturas de que você gostar. É possível selecionar mais de uma.";
            return;
        }

        if (selected.Count != selectedCount)
        {
            SelectedLutText.Text = $"{selectedCount} selecionadas. Aguarde a geração das miniaturas restantes.";
            ExportButton.IsEnabled = false;
            PdfButton.IsEnabled = false;
            return;
        }

        SelectedLutText.Text = selected.Count == 1
            ? $"1 LUT selecionada: {selected[0].Name}"
            : $"{selected.Count} LUTs selecionadas para o PDF.";
        ExportButton.IsEnabled = !_isGenerating && selected.Count == 1;
        PdfButton.IsEnabled = !_isGenerating;
    }

    private async void Export_Click(object sender, RoutedEventArgs e)
    {
        var selections = GetSelectedReadyPreviews();
        if (selections.Count != 1) return;
        var selected = selections[0];
        var safeName = string.Concat(selected.Name.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Title = "Exportar frame com LUT",
            Filter = "Imagem JPEG|*.jpg",
            FileName = $"{Path.GetFileNameWithoutExtension(_videoPath)}_{safeName}.jpg"
        };
        if (dialog.ShowDialog() != true) return;

        ExportButton.IsEnabled = false;
        StatusText.Text = "Exportando frame em resolução original…";
        try
        {
            await _ffmpeg.ExportLutFrameAsync(_videoPath, _selectedTime, selected.Path, dialog.FileName, CancellationToken.None);
            StatusText.Text = "Frame exportado com sucesso.";
            System.Windows.MessageBox.Show(this, "O frame tratado foi salvo.", "LUT Choiser", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText.Text = "Não foi possível exportar o frame.";
            System.Windows.MessageBox.Show(this, ex.Message, "Falha ao exportar", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            UpdateActionAvailability();
        }
    }

    private async void ExportPdf_Click(object sender, RoutedEventArgs e)
    {
        var selections = GetSelectedReadyPreviews();
        if (selections.Count == 0) return;

        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Title = "Salvar PDF das LUTs selecionadas",
            Filter = "Documento PDF|*.pdf",
            FileName = $"{Path.GetFileNameWithoutExtension(_videoPath)}_LUTs_selecionadas.pdf"
        };
        if (dialog.ShowDialog() != true) return;

        PdfButton.IsEnabled = false;
        ExportButton.IsEnabled = false;
        StatusText.Text = $"Montando PDF com {selections.Count} LUT{(selections.Count == 1 ? string.Empty : "s")} selecionada{(selections.Count == 1 ? string.Empty : "s")}…";
        try
        {
            await PdfExportService.ExportAsync(selections, dialog.FileName, CancellationToken.None);
            StatusText.Text = "PDF salvo com as miniaturas e os nomes das LUTs selecionadas.";
            System.Windows.MessageBox.Show(this, "O PDF foi salvo com sucesso.", "LUT Choiser", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusText.Text = "Não foi possível gerar o PDF.";
            System.Windows.MessageBox.Show(this, ex.Message, "Falha ao gerar PDF", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            UpdateActionAvailability();
        }
    }

    protected override void OnClosed(EventArgs e)
    {
        _generationCancellation?.Cancel();
        try { if (Directory.Exists(_workspace)) Directory.Delete(_workspace, recursive: true); } catch { /* temporary files can be locked */ }
        base.OnClosed(e);
    }

    private List<string> GetLutFiles()
    {
        try
        {
            return Directory.EnumerateFiles(_lutFolder, "*.cube", SearchOption.AllDirectories)
                .OrderBy(path => Path.GetFileName(path), StringComparer.CurrentCultureIgnoreCase)
                .ToList();
        }
        catch (UnauthorizedAccessException) { return []; }
    }

    private void UpdateActionAvailability()
    {
        RegenerateButton.IsEnabled = !_isGenerating;
        CancelButton.IsEnabled = _isGenerating;
        PreviousPageButton.IsEnabled = !_isGenerating && _currentPage > 0;
        NextPageButton.IsEnabled = !_isGenerating && _currentPage < GetPageCount() - 1;
        var selected = GetSelectedReadyPreviews();
        var selectedCount = _previews.Count(preview => preview.IsSelected);
        var allSelectedAreReady = selected.Count == selectedCount;
        ExportButton.IsEnabled = !_isGenerating && allSelectedAreReady && selected.Count == 1;
        PdfButton.IsEnabled = !_isGenerating && allSelectedAreReady && selected.Count > 0;
    }

    private List<LutPreview> GetSelectedReadyPreviews() => _previews
        .Where(preview => preview.IsReady && !string.IsNullOrWhiteSpace(preview.ThumbnailPath))
        .Where(preview => preview.IsSelected)
        .ToList();

    private void ShowCurrentPage()
    {
        _suppressSelectionChanges = true;
        try
        {
            PreviewList.SelectedItems.Clear();
            _visiblePreviews.Clear();
            foreach (var preview in _previews.Skip(_currentPage * PreviewsPerPage).Take(PreviewsPerPage))
                _visiblePreviews.Add(preview);
            foreach (var preview in _visiblePreviews.Where(preview => preview.IsSelected))
                PreviewList.SelectedItems.Add(preview);
        }
        finally
        {
            _suppressSelectionChanges = false;
        }

        PreviewList.Visibility = Visibility.Visible;
        EmptyStateText.Visibility = Visibility.Collapsed;
        var first = _currentPage * PreviewsPerPage + 1;
        var last = Math.Min(first + PreviewsPerPage - 1, _previews.Count);
        PageInfoText.Text = $"{first}–{last} de {_previews.Count}";
        UpdateActionAvailability();
    }

    private void ShowPageNavigationError(Exception exception)
    {
        StatusText.Text = "Não foi possível abrir este grupo de clipes. Você pode tentar novamente.";
        System.Windows.MessageBox.Show(this, exception.Message, "Falha ao trocar de grupo", MessageBoxButton.OK, MessageBoxImage.Error);
        UpdateActionAvailability();
    }

    private int GetPageCount() => Math.Max(1, (int)Math.Ceiling(_previews.Count / (double)PreviewsPerPage));

    private void PreviewVideo_MediaOpened(object sender, RoutedEventArgs e)
    {
        if (sender is MediaElement video)
        {
            video.Opacity = 1;
            video.Position = TimeSpan.Zero;
            video.Play();
        }
    }

    private void PreviewVideo_MediaEnded(object sender, RoutedEventArgs e)
    {
        if (sender is MediaElement video)
        {
            video.Position = TimeSpan.Zero;
            video.Play();
        }
    }

    private void PreviewVideo_MediaFailed(object sender, ExceptionRoutedEventArgs e)
    {
        if (sender is MediaElement video)
        {
            video.Stop();
            video.Opacity = 0;
        }

        if (sender is FrameworkElement { DataContext: LutPreview preview })
        {
            preview.Detail = $"O clipe não pôde ser reproduzido e foi mostrado como imagem: {e.ErrorException.Message}";
        }
    }

    private static string FormatTime(TimeSpan time) => $"{(int)time.TotalMinutes:00}:{time.Seconds:00}.{time.Milliseconds:000}";
}
