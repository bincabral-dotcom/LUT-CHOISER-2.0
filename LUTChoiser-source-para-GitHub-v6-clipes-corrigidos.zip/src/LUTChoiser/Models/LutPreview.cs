using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LutChoiser.Models;

public sealed class LutPreview : INotifyPropertyChanged
{
    private string? _thumbnailPath;
    private Uri? _thumbnailUri;
    private Uri? _previewVideoUri;
    private bool _isSelected;
    private string _stateLabel = "Na fila";
    private string _detail = string.Empty;

    public LutPreview(string path)
    {
        Path = path;
        Name = System.IO.Path.GetFileNameWithoutExtension(path);
    }

    public string Name { get; }
    public string Path { get; }

    public string? ThumbnailPath
    {
        get => _thumbnailPath;
        set => SetField(ref _thumbnailPath, value);
    }

    public Uri? ThumbnailUri
    {
        get => _thumbnailUri;
        set => SetField(ref _thumbnailUri, value);
    }

    public Uri? PreviewVideoUri
    {
        get => _previewVideoUri;
        set => SetField(ref _previewVideoUri, value);
    }

    public bool IsSelected
    {
        get => _isSelected;
        set => SetField(ref _isSelected, value);
    }

    public string StateLabel
    {
        get => _stateLabel;
        set => SetField(ref _stateLabel, value);
    }

    public string Detail
    {
        get => _detail;
        set => SetField(ref _detail, value);
    }

    public bool IsReady => PreviewVideoUri is not null && !string.IsNullOrWhiteSpace(ThumbnailPath);

    public event PropertyChangedEventHandler? PropertyChanged;

    private void SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        if (propertyName is nameof(PreviewVideoUri) or nameof(ThumbnailPath))
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsReady)));
    }
}

