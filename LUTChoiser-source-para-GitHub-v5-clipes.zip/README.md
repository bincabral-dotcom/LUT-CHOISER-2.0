# LUT Choiser

Aplicativo Windows para comparar rapidamente LUTs (`.cube`) em um frame de vídeo.

## O que ele faz

1. Importe um vídeo. O aplicativo abre diretamente na última pasta de vídeos utilizada.
2. Navegue até o instante desejado na linha do tempo: um clique em qualquer ponto da barra leva diretamente a esse instante, que será o início das prévias.
3. Selecione a pasta que contém sua biblioteca de LUTs (`.cube`). A busca inclui subpastas e a pasta fica salva para as próximas aberturas.
4. Gere as prévias. Cada LUT recebe um clipe sem áudio de até 5 segundos a partir do instante escolhido. Para manter o aplicativo leve, seis clipes em reprodução aparecem por vez, em três colunas, com navegação entre os grupos.
5. Clique nas miniaturas de que gostar para selecionar uma ou várias. Gere um PDF com as selecionadas e seus nomes, ou exporte em JPEG o frame de uma única LUT.

Cada prévia é gerada pelo FFmpeg com interpolação tetraédrica, portanto corresponde à LUT real, não a uma simulação de cor feita pela interface.

O aplicativo inicia maximizado e inclui um ícone próprio no executável.

## Rodar no computador

O aplicativo publicado pelo GitHub Actions já traz o FFmpeg e é portátil:

1. Baixe o artefato `LUT-Choice-win-x64` na aba **Actions** do GitHub.
2. Extraia o ZIP para uma pasta comum (não execute de dentro do arquivo compactado).
3. Abra `LUT Choiser.exe`.

O arquivo ZIP de distribuição é autocontido, mas o Windows precisa extrair o executável antes de iniciá-lo. Isso é uma limitação de segurança do próprio Windows.

## Compilar no GitHub

### Enviar o projeto compactado ao GitHub

1. Crie um repositório no GitHub e, uma única vez, envie o arquivo `build-windows.yml` para `.github/workflows/build-windows.yml`.
2. Envie `LUTChoiser-source-para-GitHub.zip` para a raiz desse repositório usando **Add file** → **Upload files**.
3. O envio do ZIP inicia a ação automaticamente. Ela o extrai somente no computador de compilação do GitHub.
4. Ao terminar, baixe o artefato `LUT-Choiser-win-x64`. Ele contém `LUT-Choiser-win-x64.zip`, pronto para distribuir.

> O arquivo YAML precisa ficar fora do ZIP para o GitHub Actions reconhecê-lo. O projeto inteiro pode permanecer compactado no repositório; a ação faz a extração temporariamente e compila o aplicativo.

## Requisitos

- Windows 10/11, 64 bits.
- Nenhuma instalação adicional ao usar o pacote publicado pelo GitHub.
- LUTs no formato `.cube` compatível com o filtro `lut3d` do FFmpeg.

## Licenças de terceiros

O pacote gerado inclui `ffmpeg.exe` e `ffprobe.exe`, instalados no runner de compilação pelo Chocolatey. O FFmpeg é distribuído sob GPL, cuja cópia e avisos acompanham o pacote quando disponíveis. Consulte [ffmpeg.org/legal.html](https://ffmpeg.org/legal.html) para detalhes. LUT Choiser apenas inicia esses executáveis para processar mídia.

